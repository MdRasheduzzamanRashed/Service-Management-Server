import express from "express";
import http from "http";
import cors from "cors";
import dotenv from "dotenv";
import { connectDB } from "./db.js";
import authRoutes from "./routes/auth.js";
import requestsRoutes from "./routes/requests.js";
import offersRoutes from "./routes/offers.js";
import serviceOrdersRoutes from "./routes/serviceOrders.js";
import notificationsRoutes from "./routes/notifications.js";
import { initSocket } from "./socket.js";

dotenv.config();

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 8000;

// Middlewares
app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(express.json());

// Ensure DB connection initialized
await connectDB();

// Routes
app.use(authRoutes);
app.use(requestsRoutes);
app.use(offersRoutes);
app.use(serviceOrdersRoutes);
app.use(notificationsRoutes);

// Health check
app.get("/", (req, res) => {
  res.json({ status: "ok" });
});

// Init Socket.IO
initSocket(server);

server.listen(PORT, () => {
  console.log("Service Management backend listening on port", PORT);
});