import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import { db } from "../db.js";

dotenv.config();

const router = express.Router();

// POST /register
router.post("/register", async (req, res) => {
  try {
    const { name, companyName, email, password, role } = req.body;

    if (!name || !companyName || !email || !password || !role) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const existing = await db.collection("users").findOne({ email });
    if (existing) {
      return res.status(400).json({ error: "Email already registered" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = {
      name,
      companyName,
      email,
      password: hashedPassword,
      role,
      createdAt: new Date()
    };

    const result = await db.collection("users").insertOne(newUser);
    const savedUser = { ...newUser, _id: result.insertedId };

    const token = jwt.sign(
      {
        id: savedUser._id,
        name: savedUser.name,
        companyName: savedUser.companyName,
        email: savedUser.email,
        role: savedUser.role
      },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    return res.json({
      message: "Registration successful",
      token,
      user: {
        name: savedUser.name,
        companyName: savedUser.companyName,
        email: savedUser.email,
        role: savedUser.role
      }
    });
  } catch (err) {
    console.error("Register error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

// POST /login
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password required" });
    }

    const user = await db.collection("users").findOne({ email });
    if (!user) {
      return res.status(400).json({ error: "Invalid email or password" });
    }

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) {
      return res.status(400).json({ error: "Invalid email or password" });
    }

    const token = jwt.sign(
      {
        id: user._id,
        name: user.name,
        companyName: user.companyName,
        email: user.email,
        role: user.role
      },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    return res.json({
      message: "Login successful",
      token,
      user: {
        name: user.name,
        companyName: user.companyName,
        email: user.email,
        role: user.role
      }
    });
  } catch (err) {
    console.error("Login error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

// POST /change-password
router.post("/change-password", async (req, res) => {
  try {
    const { email, oldPassword, newPassword } = req.body;

    if (!email || !oldPassword || !newPassword) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const user = await db.collection("users").findOne({ email });
    if (!user) {
      return res.status(400).json({ error: "User not found" });
    }

    const match = await bcrypt.compare(oldPassword, user.password);
    if (!match) {
      return res.status(400).json({ error: "Old password is incorrect" });
    }

    const hashed = await bcrypt.hash(newPassword, 10);

    await db.collection("users").updateOne(
      { email },
      { $set: { password: hashed } }
    );

    return res.json({ message: "Password updated successfully" });
  } catch (err) {
    console.error("Change password error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

export default router;