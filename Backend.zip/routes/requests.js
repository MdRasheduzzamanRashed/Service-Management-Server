import express from "express";
import { ObjectId } from "mongodb";
import { db } from "../db.js";
import { createNotification } from "../utils/createNotification.js";

const router = express.Router();

// ----------------- STATUS FILTER MAPPER -----------------
function mapStatusFilter(statusParam) {
  switch (statusParam) {
    case "in_review":
      return "InReview";
    case "evaluating":
      return "Evaluating";
    default:
      return null;
  }
}

// ----------------- LIST REQUESTS -----------------
router.get("/api/requests", async (req, res) => {
  try {
    const { status } = req.query;
    const filter = {};
    const mapped = mapStatusFilter(status);

    if (mapped) filter.status = mapped;

    const list = await db
      .collection("serviceRequests")
      .find(filter)
      .sort({ createdAt: -1 })
      .toArray();

    return res.json(list);
  } catch (err) {
    console.error("List requests error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

// ----------------- CREATE REQUEST -----------------
router.post("/api/requests", async (req, res) => {
  try {
    const body = req.body;

    if (!body.title || !body.contractId) {
      return res.status(400).json({ error: "Title and contractId are required" });
    }

    // Validate contract
    const contract = await db
      .collection("contracts")
      .findOne({ _id: new ObjectId(body.contractId) });

    if (!contract || contract.status !== "Approved") {
      return res.status(400).json({ error: "Contract must be an approved contract" });
    }

    const userRole = req.headers["x-user-role"] || "ProjectManager";

    const doc = {
      title: body.title,
      requestType: body.requestType || "Single",
      projectReference: body.projectReference || "",
      contractId: new ObjectId(body.contractId),
      startDate: body.startDate || null,
      endDate: body.endDate || null,

      commercialWeighting: body.commercialWeighting ?? 50,
      technicalWeighting: body.technicalWeighting ?? 50,
      maxOffersPerProvider: body.maxOffersPerProvider ?? 3,
      maxAcceptedOffers: body.maxAcceptedOffers ?? 1,

      domain: body.domain || "",
      role: body.role || "",
      technology: body.technology || "",
      experienceLevel: body.experienceLevel || "",

      sumOfManDays: body.sumOfManDays ?? 0,
      onsiteDays: body.onsiteDays ?? 0,
      performanceLocation: body.performanceLocation || "Onshore",
      taskDescription: body.taskDescription || "",

      requiredLanguageSkills: body.requiredLanguageSkills || [],
      mustHaveCriteria: body.mustHaveCriteria || [],
      niceToHaveCriteria: body.niceToHaveCriteria || [],
      furtherInformation: body.furtherInformation || "",

      requestedByRole: userRole,
      submissionWindowOpen: false,
      status: "Draft",
      createdAt: new Date()
    };

    const result = await db.collection("serviceRequests").insertOne(doc);
    const saved = { ...doc, _id: result.insertedId };

    // Audit
    await db.collection("auditLogs").insertOne({
      type: "ServiceRequestCreated",
      requestId: saved._id,
      at: new Date(),
      byRole: userRole
    });

    // 🔔 Notification: Draft created → Procurement officer sees it
    await createNotification({
      title: "New Service Request Created",
      message: `A new draft request "${saved.title}" was created.`,
      roles: ["ProcurementOfficer"],
      requestId: saved._id,
      createdByRole: userRole,
      type: "RequestCreated"
    });

    return res.status(201).json(saved);
  } catch (err) {
    console.error("Create request error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

// ----------------- HELPER: LOAD REQUEST -----------------
async function findRequestOr404(id, res) {
  let _id;
  try {
    _id = new ObjectId(id);
  } catch {
    res.status(400).json({ error: "Invalid request id" });
    return null;
  }
  const doc = await db.collection("serviceRequests").findOne({ _id });
  if (!doc) {
    res.status(404).json({ error: "Service request not found" });
    return null;
  }
  return doc;
}

// ----------------- SUBMIT REQUEST (PM → Procurement) -----------------
router.post("/api/requests/:id/submit", async (req, res) => {
  try {
    const id = req.params.id;
    const existing = await findRequestOr404(id, res);
    if (!existing) return;

    if (existing.status !== "Draft") {
      return res.status(400).json({ error: "Only draft requests can be submitted" });
    }

    const userRole = req.headers["x-user-role"] || "ProjectManager";

    const updated = await db.collection("serviceRequests").findOneAndUpdate(
      { _id: existing._id },
      { $set: { status: "InReview" } },
      { returnDocument: "after" }
    );

    // Audit
    await db.collection("auditLogs").insertOne({
      type: "ServiceRequestSubmitted",
      requestId: existing._id,
      at: new Date(),
      byRole: userRole
    });

    // 🔔 Notify Procurement
    await createNotification({
      title: "Service Request Submitted",
      message: `Request "${existing.title}" submitted for procurement review.`,
      roles: ["ProcurementOfficer"],
      requestId: existing._id,
      createdByRole: userRole,
      type: "RequestSubmitted"
    });

    return res.json(updated.value);
  } catch (err) {
    console.error("Submit request error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

// ----------------- PROCUREMENT REVIEW -----------------
router.post("/api/requests/:id/procurement-review", async (req, res) => {
  try {
    const id = req.params.id;
    const { approve, comments } = req.body;

    const existing = await findRequestOr404(id, res);
    if (!existing) return;

    if (existing.status !== "InReview") {
      return res.status(400).json({ error: "Request is not in review" });
    }

    const userRole = req.headers["x-user-role"] || "ProcurementOfficer";

    let newStatus = "Rejected";
    let submissionWindowOpen = false;

    if (approve) {
      newStatus = "OpenForOffers";
      submissionWindowOpen = true;
    }

    const updated = await db.collection("serviceRequests").findOneAndUpdate(
      { _id: existing._id },
      { $set: { status: newStatus, submissionWindowOpen } },
      { returnDocument: "after" }
    );

    // Audit
    await db.collection("auditLogs").insertOne({
      type: "ProcurementReview",
      requestId: existing._id,
      at: new Date(),
      byRole: userRole,
      approve: !!approve,
      comments: comments || ""
    });

    if (approve) {
      // 🔔 Notify PM & Planner
      await createNotification({
        title: "Request Approved",
        message: `Procurement approved "${existing.title}". Submission window opened.`,
        roles: ["ProjectManager", "ResourcePlanner"],
        requestId: existing._id,
        createdByRole: userRole,
        type: "ProcurementApproved"
      });
    } else {
      // 🔔 Notify PM only
      await createNotification({
        title: "Request Rejected",
        message: `Procurement rejected "${existing.title}". Comments: ${comments || "None"}.`,
        roles: ["ProjectManager"],
        requestId: existing._id,
        createdByRole: userRole,
        type: "ProcurementRejected"
      });
    }

    return res.json(updated.value);
  } catch (err) {
    console.error("Procurement review error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

// ----------------- CLOSE SUBMISSION WINDOW -----------------
router.post("/api/requests/:id/close-window", async (req, res) => {
  try {
    const id = req.params.id;

    const existing = await findRequestOr404(id, res);
    if (!existing) return;

    if (!existing.submissionWindowOpen) {
      return res.status(400).json({ error: "Submission window already closed" });
    }

    const updated = await db.collection("serviceRequests").findOneAndUpdate(
      { _id: existing._id },
      { $set: { submissionWindowOpen: false, status: "Evaluating" } },
      { returnDocument: "after" }
    );

    // Audit
    await db.collection("auditLogs").insertOne({
      type: "SubmissionWindowClosed",
      requestId: existing._id,
      at: new Date()
    });

    // 🔔 Notify PM + Planner
    await createNotification({
      title: "Submission Window Closed",
      message: `Submission window for "${existing.title}" is closed. Offers ready for evaluation.`,
      roles: ["ProjectManager", "ResourcePlanner"],
      requestId: existing._id,
      createdByRole: "System",
      type: "SubmissionWindowClosed"
    });

    return res.json(updated.value);
  } catch (err) {
    console.error("Close window error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

export default router;
